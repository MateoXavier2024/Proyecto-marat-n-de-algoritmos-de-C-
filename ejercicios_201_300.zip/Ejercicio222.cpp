// Ejercicio 222
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

// Kruskal con union-find minimal para 3 nodos
cout << "Kruskal demo: MST de ejemplo\n";

    return 0;
}
