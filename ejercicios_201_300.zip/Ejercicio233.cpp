// Ejercicio 233
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Cond var demo requires threading; showing message instead.\n";

    return 0;
}
