// Ejercicio 235
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Comparar dos directorios demo: listar archivos del directorio actual\n";
system("ls -1");

    return 0;
}
