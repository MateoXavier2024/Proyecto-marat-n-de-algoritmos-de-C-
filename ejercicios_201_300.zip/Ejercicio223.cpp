// Ejercicio 223
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Simulacion SIR simplificada (demonstracion)\n";

    return 0;
}
