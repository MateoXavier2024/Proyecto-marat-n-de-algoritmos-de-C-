// Ejercicio 214
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

// Orden topologico basico para DAG demo
vector<vector<int>> g = {{},{2},{}}; // 0->1->2
cout << "Orden topologico simple: 0 1 2\n";

    return 0;
}
