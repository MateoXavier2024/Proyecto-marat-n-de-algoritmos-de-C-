// Ejercicio 217
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Matrix sparse con map demo (similar a 207)\n";

    return 0;
}
