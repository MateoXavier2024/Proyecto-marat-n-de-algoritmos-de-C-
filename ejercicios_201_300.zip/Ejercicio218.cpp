// Ejercicio 218
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "BFS 0/1 (deque) stub demo\n";

    return 0;
}
