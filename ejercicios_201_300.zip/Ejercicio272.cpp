// Ejercicio 272
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Page replacement simulation: LRU/FIFO demo message\n";

    return 0;
}
