// Ejercicio 230
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Hill-climbing demo: buscar mayor de función simple en vecindario\n";

    return 0;
}
