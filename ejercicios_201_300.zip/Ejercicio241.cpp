// Ejercicio 241
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Clustering de palabras demo (bag-of-words)\n";

    return 0;
}
