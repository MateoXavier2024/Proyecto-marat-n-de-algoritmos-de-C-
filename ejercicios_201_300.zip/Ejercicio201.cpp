// Ejercicio 201
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Stub: cliente FTP basico no implementado por dependencias de plataforma.\n";

    return 0;
}
