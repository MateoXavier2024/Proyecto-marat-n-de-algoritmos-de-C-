// Ejercicio 251
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Generador de tests automáticos: imprime casos para funcion suma\n";
for(int i=0;i<5;i++) cout<<i<<" "<<i+1<<"\n";

    return 0;
}
