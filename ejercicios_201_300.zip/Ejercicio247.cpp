// Ejercicio 247
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Colas con expiracion demo: mostrar mensaje\n";

    return 0;
}
