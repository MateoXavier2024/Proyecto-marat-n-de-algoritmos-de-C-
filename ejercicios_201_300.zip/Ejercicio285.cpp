// Ejercicio 285
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Search ranking demo: sort terms by frequency (hardcoded)\n";

    return 0;
}
