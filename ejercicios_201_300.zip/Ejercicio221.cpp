// Ejercicio 221
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Coloracion greedy demo para grafo pequeño\n";

    return 0;
}
