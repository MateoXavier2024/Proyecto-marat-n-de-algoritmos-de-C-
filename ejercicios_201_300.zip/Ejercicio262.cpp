// Ejercicio 262
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "RANSAC demo stub: implementacion completa extensa, mensaje demo.\n";

    return 0;
}
