// Ejercicio 270
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Motor de validacion de datos demo: regla simple x>0\n";
int x; cin>>x; cout << ((x>0)?"Valido\n":"No valido\n");

    return 0;
}
