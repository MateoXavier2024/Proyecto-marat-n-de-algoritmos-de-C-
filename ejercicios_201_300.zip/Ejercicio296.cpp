// Ejercicio 296
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Asignacion tareas greedy demo: asignar tareas a trabajadores secuencialmente\n";

    return 0;
}
