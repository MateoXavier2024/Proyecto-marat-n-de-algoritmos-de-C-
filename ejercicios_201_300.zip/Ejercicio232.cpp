// Ejercicio 232
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Simulacion colas con servidores multiple: demo\n";

    return 0;
}
