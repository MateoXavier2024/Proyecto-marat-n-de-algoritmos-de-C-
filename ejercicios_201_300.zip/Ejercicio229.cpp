// Ejercicio 229
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Sistema ACL demo: permisos representados en bitmask\n";

    return 0;
}
