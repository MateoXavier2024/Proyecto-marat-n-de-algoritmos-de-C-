// Ejercicio 265
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Cache con TTL demo: store item with expiry timestamp (simulado)\n";

    return 0;
}
