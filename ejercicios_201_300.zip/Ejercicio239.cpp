// Ejercicio 239
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Convertidor RAW<->WAV stub: requires audio libs; demo message.\n";

    return 0;
}
