// Ejercicio 236
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Motor de recomendaciones demo: similitud coseno simplificado\n";

    return 0;
}
