// Ejercicio 238
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Beam search demo stub\n";

    return 0;
}
