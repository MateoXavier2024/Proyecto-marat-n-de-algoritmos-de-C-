// Ejercicio 244
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Deteccion de comunidades demo: label propagation stub\n";

    return 0;
}
