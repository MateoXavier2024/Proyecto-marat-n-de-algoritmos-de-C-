// Ejercicio 215
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

// LRU Cache simple simulation using list+unordered_map
cout << "LRU Cache demo: usar list+unordered_map para acceso O(1)\n";

    return 0;
}
