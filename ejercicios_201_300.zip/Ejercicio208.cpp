// Ejercicio 208
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Busqueda A* stub: implementacion completa es extensa.\n";

    return 0;
}
