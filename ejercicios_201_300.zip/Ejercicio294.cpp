// Ejercicio 294
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Pollard-rho stub: factorization advanced, demo message\n";

    return 0;
}
