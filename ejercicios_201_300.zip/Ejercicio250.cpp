// Ejercicio 250
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Matrices dispersas y multiplicacion demo (pequena)\n";

    return 0;
}
