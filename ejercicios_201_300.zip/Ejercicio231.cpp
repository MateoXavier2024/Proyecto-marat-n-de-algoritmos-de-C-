// Ejercicio 231
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Calculadora de polinomios demo: calcular derivada numerica simple\n";

    return 0;
}
