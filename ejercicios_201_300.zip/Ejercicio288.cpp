// Ejercicio 288
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Backprop demo stub: simple perceptron already shown earlier.\n";

    return 0;
}
