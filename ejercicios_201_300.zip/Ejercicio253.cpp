// Ejercicio 253
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Backup incremental demo: copiar fileA->fileB (demo)\n";

    return 0;
}
