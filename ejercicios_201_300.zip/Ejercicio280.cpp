// Ejercicio 280
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "LZW compression stub: demo message\n";

    return 0;
}
