// Ejercicio 278
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Scripting engine stub: execute built-in commands 'ping'\n";
string cmd; cin>>cmd;
if(cmd=="ping") cout<<"pong\n";

    return 0;
}
