// Ejercicio 255
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {
    cout << "Utilidades matematicas: gcd(48,18)=";
    body += "auto gcd = [](int a,int b){ while(b){int t=b;b=a%b;a=t;} return a; };
    cout << gcd(48,18) << "\n";";
    return 0;
}
