// Ejercicio 271
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Skip list stub: implementacion larga, demo message\n";

    return 0;
}
