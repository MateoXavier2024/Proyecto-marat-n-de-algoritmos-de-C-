// Ejercicio 273
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Auth tokens simple demo: issue token 'abc123'\n";

    return 0;
}
