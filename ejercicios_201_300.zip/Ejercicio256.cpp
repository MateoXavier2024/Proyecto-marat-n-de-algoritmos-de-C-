// Ejercicio 256
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Particion heuristica k-subarrays demo (greedy)\n";

    return 0;
}
