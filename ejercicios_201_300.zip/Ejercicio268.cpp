// Ejercicio 268
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Set cover greedy demo: seleccionar conjuntos que cubran elementos\n";

    return 0;
}
