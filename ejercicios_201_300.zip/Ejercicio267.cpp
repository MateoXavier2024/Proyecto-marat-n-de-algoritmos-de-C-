// Ejercicio 267
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Convertidor audio->espectrograma demo: message only\n";

    return 0;
}
