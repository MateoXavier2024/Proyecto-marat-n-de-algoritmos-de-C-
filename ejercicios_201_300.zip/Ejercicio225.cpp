// Ejercicio 225
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Parser JSON simplificado no completo: demo\n";

    return 0;
}
