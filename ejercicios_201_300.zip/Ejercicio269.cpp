// Ejercicio 269
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Merge archivos por bloques demo: lee stdin y escribe stdout\n";
string line;
while(getline(cin,line)) cout<<line<<"\n";

    return 0;
}
