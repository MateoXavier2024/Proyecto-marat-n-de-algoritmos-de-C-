// Ejercicio 234
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Parser booleano simple: evalua 'true' o 'false' ingresado\n";
string s; cin >> s;
cout << ((s=="true")?"Verdadero\n":"Falso\n");

    return 0;
}
