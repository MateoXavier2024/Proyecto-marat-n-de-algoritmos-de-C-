// Ejercicio 284
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "2-opt heuristic demo for route improvement: swap two nodes\n";

    return 0;
}
