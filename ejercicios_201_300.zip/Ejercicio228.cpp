// Ejercicio 228
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Bloom filter stub (demo): use bitset and hash functions for simple test\n";

    return 0;
}
