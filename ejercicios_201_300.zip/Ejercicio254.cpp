// Ejercicio 254
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Huffman adaptativo stub: demo message\n";

    return 0;
}
