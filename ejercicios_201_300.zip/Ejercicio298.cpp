// Ejercicio 298
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Generador de laberintos DFS demo: prints simple pattern\n";

    return 0;
}
