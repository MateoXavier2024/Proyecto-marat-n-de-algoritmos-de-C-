// Ejercicio 212
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Motor de reglas simple: si x>10 imprime mensaje.\n";
int x; cout << "X?: "; cin >> x;
if(x>10) cout << "Regla activada: x>10\n"; else cout << "No activada\n";

    return 0;
}
