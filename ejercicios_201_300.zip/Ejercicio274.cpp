// Ejercicio 274
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Matching bipartito (Hopcroft-Karp) stub: message\n";

    return 0;
}
