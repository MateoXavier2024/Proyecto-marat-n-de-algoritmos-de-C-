// Ejercicio 266
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "K-shortest paths stub: demo message\n";

    return 0;
}
