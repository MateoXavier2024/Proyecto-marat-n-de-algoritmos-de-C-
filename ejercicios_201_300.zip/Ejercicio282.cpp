// Ejercicio 282
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Graph isomorphism heuristic demo: compare degree sequences\n";

    return 0;
}
