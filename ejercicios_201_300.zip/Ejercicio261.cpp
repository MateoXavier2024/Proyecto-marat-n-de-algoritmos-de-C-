// Ejercicio 261
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Mini-ORM demo: vector de structs actuando como 'tabla'\n";

    return 0;
}
