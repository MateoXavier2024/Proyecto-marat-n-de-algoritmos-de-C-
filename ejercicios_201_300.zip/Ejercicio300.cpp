// Ejercicio 300
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Mini-interpreter: evalua expresion simple 1+2*3 = " << (1+2*3) << "\n";

    return 0;
}
