// Ejercicio 220
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Parser AST simple: convertir 1+2 en nodo y calcular resultado\n";
cout << "Resultado 1+2 = " << (1+2) << "\n";

    return 0;
}
