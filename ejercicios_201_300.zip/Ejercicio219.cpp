// Ejercicio 219
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {

cout << "Simulador 1D de colisiones simple: dos masas que intercambian velocidad\n";
double v1=1.0, v2=-1.0;
cout << "Antes v1="<<v1<<" v2="<<v2<<"\n";
swap(v1,v2);
cout << "Despues v1="<<v1<<" v2="<<v2<<"\n";

    return 0;
}
